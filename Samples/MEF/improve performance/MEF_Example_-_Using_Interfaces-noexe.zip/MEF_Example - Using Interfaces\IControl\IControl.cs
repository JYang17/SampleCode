﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace ControlInterface
{
    public interface IControl
    {    
    }

    public interface IControlLibrary1 : IControl
    {
    }

    public interface IControlLibrary2 : IControl
    {
    }
}
