namespace LiviosPizzeria
{
    public class Pizza
    {
    }
}