namespace LiviosPizzeria
{
    public class Ingredients
    {
    }
}