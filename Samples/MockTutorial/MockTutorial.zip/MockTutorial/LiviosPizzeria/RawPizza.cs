namespace LiviosPizzeria
{
    public class RawPizza : IRawPizza
    {
    }
}