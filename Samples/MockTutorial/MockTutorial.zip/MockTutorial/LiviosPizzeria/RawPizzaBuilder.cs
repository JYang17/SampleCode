namespace LiviosPizzeria
{
    public class RawPizzaBuilder : IRawPizzaBuilder
    {
        public RawPizza CreatePizza(Ingredients ingredients)
        {
            throw new System.NotImplementedException();
        }
    }
}