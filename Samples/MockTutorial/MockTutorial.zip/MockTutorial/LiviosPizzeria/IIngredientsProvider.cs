namespace LiviosPizzeria
{
    public interface IIngredientsProvider
    {
        Ingredients GetIngredients();
    }
}