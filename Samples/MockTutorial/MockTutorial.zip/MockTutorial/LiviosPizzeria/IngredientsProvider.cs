namespace LiviosPizzeria
{
    public class IngredientsProvider : IIngredientsProvider
    {
        public Ingredients GetIngredients()
        {
            throw new System.NotImplementedException();
        }
    }
}