namespace LiviosPizzeria
{
    public interface IRawPizza
    {
    }
}